package com.revature.mavenprojects.Mavenapp1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;

public class Demo {
	

	    public static void getSkills(int candidateId) throws Exception {
	        // 
	        String query = "{ call getcandidateskill(?) }";
	        ResultSet rs;

	       Connection conn = DBUtil.getConnection();
	        
	       CallableStatement cmt = conn.prepareCall(query);

	           cmt.setInt(1, candidateId);

	            rs = cmt.executeQuery();
	            
	            while (rs.next()) {
	            	System.out.println( rs.getString(1)	 + " "   + rs.getString(2) + " "   + rs.getString(3) + " "   + rs.getString(4));
	                        
	            	}
	        
	    }

	   
	    public static void main(String[] args)  throws Exception{
	        getSkills(3);
	    }
	}
