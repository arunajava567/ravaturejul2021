package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Employee;
import com.example.dao.EmployeeDaoImpl;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService 
{
@Autowired
EmployeeDaoImpl dao;


@Override
public Employee employeeCreation(Employee emp) {
	return dao.save(emp);
			//.employeeCreation(emp);
}


@Override
public Employee getEmployeeById(int id) 
{  
return dao.findById(id).get();//dao.getEmployeeById(id);
}

/* (non-Javadoc)
 * @see com.example.service.EmployeeService#getAllEmployee()
 */
@Override
public List<Employee> getAllEmployee() 
{
return dao.findAll();  //.getAllEmployee();
}


@Override
public Employee delete(int id) 
{   Employee e=dao.findById(id).get();
if(e !=null)
	dao.deleteById(id);
	return e;  //.deleteById(id);
}


@Override
public Employee updateEmployee(Employee emp) {
	boolean b = dao.existsById(emp.getId());
	Employee e=new Employee();
	if (b) {
		dao.save(emp);
		 e=dao.findById(emp.getId()).get();
	} 

	return  e;
}

}