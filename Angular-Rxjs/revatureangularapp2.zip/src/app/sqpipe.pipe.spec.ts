import { SqpipePipe } from './sqpipe.pipe';

describe('SqpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SqpipePipe();
    expect(pipe).toBeTruthy();
  });
});
