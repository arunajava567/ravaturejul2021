import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sqpipe'
})                               //interface 
export class SqpipePipe implements PipeTransform {

  transform(value: number): number{
    return value * value;
  }

}
