/*import { Component } from "@angular/core";
//import { filter,map } from "rxjs/operators";
//import { interval, of, timer } from "rxjs";
import { Observable } from "rxjs";
//import { AsyncSubject } from "rxjs";
@Component({
  selector: 'app-root',
  template: `<h1>Filter Example</h1>`,
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  val:any;
   title:any;
  obs:any;
  error:any;
  constructor() { 
      this.title = 'Angular Observable using RxJs - Getting Started';
      this.obs = new Observable((observer) => {
       console.log("Observable starts")
         observer.next("1")
         observer.next("2")
         observer.next("3")
         observer.next("4")
         observer.next("5")
    
        this.obs.subscribe(
         this.val => { console.log(this.val) },
         this.error => { console.log("error")},
         () => {console.log("Completed")}
       )
     }
   
   } 

   */

  /* obs = new Observable((observer) => {
      observer.next(1)
      observer.next(2)
      observer.next(3)
      observer.next(4)
      observer.next(5)
      observer.complete()
    }).pipe(
      filter(data => data > 2),                    //filter Operator
      map((val) => {return val as number * 2}),    //map operator
    )
    data = [];
     ngOnInit() {
      this.obs.subscribe(
        val => {
          console.log(this.data)
        }
      )
    }
  */

   /*
   constructor() { }
  
   ngOnInit() {
    
       // Create a new Observable
       const sqnc = new Observable(countOnetoTen);
     
       // Execute the Observable and print the
       // result of each notification
       // next() is a call to countOnetoTen method
       // to get the next value from the observable
       sqnc.subscribe({
           next(num) { 
              console.log(num); 
            }
       });
        
       // This function runs when subscribe()
       // is called

       
       function countOnetoTen(observer:any) {
            
           for(var i = 1; i <= 10; i++) {
                
               // Calls the next observable
               // notification
               observer.next(i);
           }
        
           // Unsubscribe after completing
           // the sequence
           return   {unsubscribe(){}};
       }
   }
*/






 /* ngOnInit() {
    of(1,2,3,4,5,6,7,8,9,10)
      .pipe(
        filter(val => {
          return val %2==0;
        }),
      )
      .subscribe(val => console.log(val));

//2
const subject = new Subject();
      //First Observer
      subject.subscribe({
         next: (data) => console.log('First observer prints '+ data)
      });
      subject.next(1);
      //Second Observer
      subject.subscribe({
         next: (data) => console.log('Second observer prints '+ data)
      });
      subject.next(34);
      subject.next(14);

//3
const subject2 = new BehaviorSubject(0);
   //First Observer
   subject2.subscribe({
      next: (data) => console.log('First observer prints '+ data)
   });
   subject2.next(1111);
   subject2.next(2222);
   //Second Observer
   subject2.subscribe({
      next: (data) => console.log('Second observer prints '+ data)
   });
   subject2.next(3333);

  }

  //4

  */
  
 //}


/*
import { Component, OnInit } from '@angular/core';
import { Observable, of} from 'rxjs';
import { map, filter, tap } from 'rxjs/operators'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
   data:any = [];
  obs = new Observable((observer) => {
    observer.next(1)
    observer.next(2)
    observer.next(3)
    observer.next(4)
    observer.next(5)
    observer.complete()
  }).pipe(
    filter(data => data > 2),                    //filter Operator
    map((val) => {return val as number * 2}),    //map operator
  )
  ngOnInit() {
    this.obs.subscribe(
      val => {
        console.log(this.data)
      }
    )
  }
 
}
*/
/*
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Angular Observable using RxJs - Getting Started';
 



  obs = new Observable((observer) => {
    console.log("Observable starts")
      observer.next("1")
      observer.next("2")
      observer.next("3")
      observer.next("4")
      observer.next("5")
  })
 
  data=[];
 
  ngOnInit() {
 
    this.obs.subscribe(
      val=> { console.log(val) },
      error => { console.log("error")},
      () => {console.log("Completed")}
    )
  }


}

*/
 

import { Component } from '@angular/core';
import { ajax } from 'rxjs/ajax';
import { map } from 'rxjs/operators'

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})
export class AppComponent {
   title = '';
    data:any;
   constructor() {
      this.data = {"id" :'' ,"name":''};
      this.title = "RxJs with Angular";
      this.getData();
   }
   getData() {
      const response = ajax('https://jsonplaceholder.typicode.com/users') //fetch - load from backend
         .pipe(map(e => e.response));
      response.subscribe(res => {
         console.log(res);
         this.data = res;
      });
   }
}

   
/*

  title = 'revatureangularapp2';
  lastLoggedInTime = new Date();

  names=["ram","raj","kiran","amith","smith","john"];

  sname='Soumyasree';
  Object = { "id": "101",  "name": "Ram"};

    image="https:\\www.google.com\imgres?imgurl=https%3A%2F%2Fwww.olympus-imaging.co.in%2Fcontent%2F000107506.jpg&imgrefurl=https%3A%2F%2Fwww.olympus-imaging.co.in%2Fproduct%2Fdslr%2Fem1mk3%2Fsample.html&tbnid=NZ6unGWQe6yEPM&vet=12ahUKEwiOkpKw26jyAhXSsksFHSsuBhQQMygAegUIARDMAQ..i&docid=d69I-ky6I-NRDM&w=5184&h=3888&q=sample%20images&ved=2ahUKEwiOkpKw26jyAhXSsksFHSsuBhQQMygAegUIARDMAQ";
  x=Math.abs(34);

  */
