import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component'
import { SqpipePipe } from './sqpipe.pipe'
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,AboutusComponent,ContactusComponent,SqpipePipe
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
    ],
  providers: [],  //service
  bootstrap: [AppComponent]//root componnet, parent compoennt , which starts 
})
export class AppModule { 

}
