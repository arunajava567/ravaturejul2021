import { Component } from '@angular/core';

//meta data 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//component  ,typescript 
export class AppComponent {
  title = 'My Revature title ';
  firstName ='Anjan';
  lastName='Pradhan';


  
}
