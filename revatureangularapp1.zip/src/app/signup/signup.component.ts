import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  //templateUrl: './signup.component.html',
  template:' <h1> signup Componnetusing Template  </h1>',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
   
  constructor() { 
    var city='Chennai';
    console.log("in constructor"); //step1

  }
  ngOnChanges() {
    console.log(" on changes  "); //step1

  }
  ngOnInit(): void {
    console.log(" init "); //step1

  }
  ngDoCheck() {
    console.log(" changes  "); //step1
  }
  ngAfterContentInit()  {
    console.log("Invoked once after Angular performs any content projection into the component’s view");
  }

  ngAfterContentChecked()  {
    console.log("content checked");
  }
  ngAfterViewInit()  {
    console.log("View is initew");
  }
  ngAfterViewChecked()  {
    console.log("View is checked ");
  }
  
  ngOnDestroy() {
    console.log("destroy");
  }


}
