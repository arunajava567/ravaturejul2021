package com.revature.bloodbank.exception;

public class BloodBankNotFoundException {

}
