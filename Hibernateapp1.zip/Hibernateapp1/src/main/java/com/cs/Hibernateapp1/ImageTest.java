package com.cs.Hibernateapp1;

import java.io.File;
import java.io.FileInputStream;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

public class ImageTest {
public static void main(String[] args) {
	
	Session session = new Configuration().configure().buildSessionFactory().openSession();
	session.beginTransaction();
	
	File file = new File("E:\\123.JPG");
    byte[] bFile = new byte[(int) file.length()];
    
    try {
     FileInputStream fileInputStream = new FileInputStream(file);
     //convert file into array of bytes
     fileInputStream.read(bFile);
     fileInputStream.close();
    } catch (Exception e) {
     e.printStackTrace();
    }
    
   Image i = new Image();
   i.setImageId(1);
    i.setImage(bFile);
    
   
    
	try{
		 session.save(i);
		session.getTransaction().commit();
		System.out.println("Image inserted successfully");
		
	}catch(HibernateException e){
		e.printStackTrace();
	}finally{
		if(session!=null){
			session.close();
		}
	}
}
}
