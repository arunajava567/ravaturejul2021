package com.cs.Hibernateapp1;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class EmployeeTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		session.beginTransaction();
		
		Employee employee1 = new Employee();
		employee1.setEmployeeId(1009);
		employee1.setEmployeeName("abc");
		Employee employee2 = new Employee();
		employee2.setEmployeeId(2009);
		employee2.setEmployeeName("abcd");
		Employee employee3 = new Employee();
		employee3.setEmployeeId(3007);
		employee3.setEmployeeName("xyz"); //transcient state
		
		try{
			session.save(employee1); //insert 
			session.save(employee2);                //persistent state
			session.save(employee3);
			
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
			
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();   //detached stated 
			}
		}
		
		
	}

}
