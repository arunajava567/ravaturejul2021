package com.cs.one2one;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;


public class One_TOne_Test_Unidirectional {

	public static void main(String[] args) {
		Session session= new Configuration().configure().buildSessionFactory().openSession();
		
		LaptopBag bag1 = new LaptopBag();
		bag1.setBagId(1098);
		bag1.setColor("BLUE");
		
		Scholar scholar1 = new Scholar();
		scholar1.setScholarId(8);
		scholar1.setScholarName("Praveen");
		
		scholar1.setBag(bag1);
		
		LaptopBag bag2 = new LaptopBag();
		bag1.setBagId(1056);
		bag1.setColor("GREEN");
		
		Scholar scholar2 = new Scholar();
		scholar2.setScholarId(9);
		scholar2.setScholarName("Praveen");
		
		scholar2.setBag(bag2);
		
		session.beginTransaction();
			session.save(scholar1);
			session.getTransaction().commit();
			System.out.println("Data inserted successfully");
		session.close();
			
		session.beginTransaction();
		session.save(scholar2);
		session.getTransaction().commit();
		System.out.println("Data inserted successfully");
	    session.close();
		
		

	}

}
