package com.revature.practice;

public class College {
	String collegeName;
	
	void show() {
		System.out.println(" in collecge class hsow method()"+collegeName);
	}

}
