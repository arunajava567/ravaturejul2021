package com.revature.practice;
//test, client , run
public class Demo {
  public static void main(String[] args) {
		System.out.println("welcome to FSD training");
		
		Course course =new Course();  //instantiation, object creation
		System.out.println(course.courseId  +  "  "+course.courseName);
		course.readCourseDetails();
		course.dispCoursedetails();
	
		Course course1 =new Course();  //instantiation, object creation
		System.out.println(course1.courseId  +  "  "+course1.courseName);
		course1.readCourseDetails();
		course.dispCoursedetails();
		
		System.out.println(course +"   "+course1);
		
		College c=new College();
		
		c.collegeName="SRM";
		c.show();

	}

}
