import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component'
import { ContactusComponent} from './contactus/contactus.component'
import { Routes, RouterModule } from '@angular/router';

const routes : Routes = [
  { path: "contact", component : ContactusComponent },
  { path: "dashboard", canActivate : [AuthGuard] , component: DashboardComponent },
  { path: "login", component : LoginComponent }
  //{ path: "lazy1", loadChildren: 'app/lazy/lazy.module#LazyModule' }
  
  ]

  
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
