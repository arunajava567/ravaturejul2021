import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component'
import { ContactusComponent} from './contactus/contactus.component'


const routes : Routes = [
  { path: "contact", canActivate : [AuthGuard] ,component : ContactusComponent },
  { path: "dashboard", canActivate : [AuthGuard] , component: DashboardComponent },
  { path: "login", component : LoginComponent },
  { path: "lazy1", loadChildren: 'app/lazy/lazy.module#LazyModule' }
  
  ]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
